//
//  APIKey.swift
//  MyCart
//
//  Created by 유철원 on 6/13/24.
//

import Foundation
import Alamofire


enum NaverSearchAPI {
    
    static let baseURL = URL(string: "https://openapi.naver.com/v1/search")!
    
    static let token = ""
    
    enum MyAuth {
        static let clientID = "c4P810K1SQm2OFclrBcU"
        static let clientSecret = "0T0CzS4059"
    }
}
